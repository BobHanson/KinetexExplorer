 Volume in drive D has no label.
 Volume Serial Number is 245E-4518

 Directory of D:\kinetex\js\equiz

05/16/2003  05:21 AM    <DIR>          .
05/16/2003  05:21 AM    <DIR>          ..
05/16/2003  05:21 AM                 0 dir.js
05/15/2003  06:09 AM    <DIR>          js
05/02/2003  07:07 AM    <DIR>          t1quiz
05/04/2003  10:05 PM    <DIR>          t2quiz
05/08/2003  12:41 PM    <DIR>          t3quiz
05/07/2003  05:19 PM    <DIR>          t4quiz
05/07/2003  08:44 AM    <DIR>          t5quiz
               1 File(s)              0 bytes
               8 Dir(s)   8,043,192,320 bytes free
