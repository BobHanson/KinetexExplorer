//indexdata.js
//copyright Rober M. Hanson, St. Olaf College 12:00 AM 1/8/2003

//if this is changed, delete the index key terms at the end
//run index.htm
//clip index keys to this file
//also update _index.wpd and _index.pdf
//10:15 AM 2/4/2003

//this allows "," to remain
Names=new Array("Max","Joanie","Bob","Albert","Louis","Ludwig","Erwin")

//chapterdata must be loaded first so that .iKeyConcept0 can be calculated

//addinfo("mainterm")
//addinfo("  subterm, ch-page")
//addinfo("  subterm")
//addinfo("    subsubterm, ch-page")


Temp=new Array()
IndexByKey=new Array(2,20,49,52,8,13,16,33,41,60,1,6,46,40,55,56,3,4,5,7,12,15
,18,21,23,24,25,26,30,32,35,36,37,57,58,9,28,29,31,34,27,0,59,61,53,54,10,11,14,17
,22,51,42,44,47,48,19,50,38,39,43,45)
